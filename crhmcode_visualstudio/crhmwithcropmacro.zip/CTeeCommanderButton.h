// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CTeeCommanderButton wrapper class

class CTeeCommanderButton : public COleDispatchDriver
{
public:
	CTeeCommanderButton() {} // Calls COleDispatchDriver default constructor
	CTeeCommanderButton(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CTeeCommanderButton(const CTeeCommanderButton& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ITeeCommanderButton methods
public:
	void Hide()
	{
		InvokeHelper(0xc9, DISPATCH_METHOD, VT_EMPTY, nullptr, nullptr);
	}

	// ITeeCommanderButton properties
public:

};
