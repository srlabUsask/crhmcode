#pragma once
class CRHMAboutBoxDlg
{
public:
	CRHMAboutBoxDlg();
	~CRHMAboutBoxDlg();
};

