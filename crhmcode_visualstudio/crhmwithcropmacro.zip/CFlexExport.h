// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CFlexExport wrapper class

class CFlexExport : public COleDispatchDriver
{
public:
	CFlexExport() {} // Calls COleDispatchDriver default constructor
	CFlexExport(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CFlexExport(const CFlexExport& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IFlexExport methods
public:
	long get_Width()
	{
		long result;
		InvokeHelper(0xb, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, nullptr);
		return result;
	}
	void put_Width(long newValue)
	{
		static BYTE parms[] = VTS_I4;
		InvokeHelper(0xb, DISPATCH_PROPERTYPUT, VT_EMPTY, nullptr, parms, newValue);
	}
	long get_Height()
	{
		long result;
		InvokeHelper(0xc, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, nullptr);
		return result;
	}
	void put_Height(long newValue)
	{
		static BYTE parms[] = VTS_I4;
		InvokeHelper(0xc, DISPATCH_PROPERTYPUT, VT_EMPTY, nullptr, parms, newValue);
	}
	void SaveToFile(LPCTSTR FileName)
	{
		static BYTE parms[] = VTS_BSTR;
		InvokeHelper(0xd, DISPATCH_METHOD, VT_EMPTY, nullptr, parms, FileName);
	}
	VARIANT SaveToStream()
	{
		VARIANT result;
		InvokeHelper(0xe, DISPATCH_METHOD, VT_VARIANT, (void*)&result, nullptr);
		return result;
	}
	BOOL Compile(LPCTSTR TargetFile)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR;
		InvokeHelper(0xc9, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, TargetFile);
		return result;
	}
	void CompileDeleteShow(long AWidth, long AHeight, LPCTSTR TempDirectoryPath, LPCTSTR FileName, LPCTSTR FlexDirectory, BOOL DeleteTemp, BOOL EmbedImages, BOOL Show)
	{
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_BSTR VTS_BOOL VTS_BOOL VTS_BOOL;
		InvokeHelper(0x12d, DISPATCH_METHOD, VT_EMPTY, nullptr, parms, AWidth, AHeight, TempDirectoryPath, FileName, FlexDirectory, DeleteTemp, EmbedImages, Show);
	}

	// IFlexExport properties
public:

};

