#include "stdafx.h"
#include "GlobalDll.h"

//DefCRHMGlobal::DefCRHMGlobal()
//{
//}
//
//
//DefCRHMGlobal::~DefCRHMGlobal()
//{
//}