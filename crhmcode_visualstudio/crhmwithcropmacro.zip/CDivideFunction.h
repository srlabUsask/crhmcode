// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CDivideFunction wrapper class

class CDivideFunction : public COleDispatchDriver
{
public:
	CDivideFunction() {} // Calls COleDispatchDriver default constructor
	CDivideFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CDivideFunction(const CDivideFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IDivideFunction methods
public:

	// IDivideFunction properties
public:

};

