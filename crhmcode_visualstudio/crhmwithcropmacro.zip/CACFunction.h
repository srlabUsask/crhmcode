// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CACFunction wrapper class

class CACFunction : public COleDispatchDriver
{
public:
	CACFunction() {} // Calls COleDispatchDriver default constructor
	CACFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CACFunction(const CACFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IACFunction methods
public:

	// IACFunction properties
public:

};

