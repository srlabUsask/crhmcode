// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CSubtractFunction wrapper class

class CSubtractFunction : public COleDispatchDriver
{
public:
	CSubtractFunction() {} // Calls COleDispatchDriver default constructor
	CSubtractFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CSubtractFunction(const CSubtractFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ISubtractFunction methods
public:

	// ISubtractFunction properties
public:

};
