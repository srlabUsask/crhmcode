// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CCumulativeFunction wrapper class

class CCumulativeFunction : public COleDispatchDriver
{
public:
	CCumulativeFunction() {} // Calls COleDispatchDriver default constructor
	CCumulativeFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CCumulativeFunction(const CCumulativeFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ICumulativeFunction methods
public:

	// ICumulativeFunction properties
public:

};

