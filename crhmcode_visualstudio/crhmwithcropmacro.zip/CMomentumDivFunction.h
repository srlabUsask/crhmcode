// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CMomentumDivFunction wrapper class

class CMomentumDivFunction : public COleDispatchDriver
{
public:
	CMomentumDivFunction() {} // Calls COleDispatchDriver default constructor
	CMomentumDivFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CMomentumDivFunction(const CMomentumDivFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IMomentumDivFunction methods
public:

	// IMomentumDivFunction properties
public:

};
