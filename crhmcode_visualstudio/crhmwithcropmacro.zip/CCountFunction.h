// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CCountFunction wrapper class

class CCountFunction : public COleDispatchDriver
{
public:
	CCountFunction() {} // Calls COleDispatchDriver default constructor
	CCountFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CCountFunction(const CCountFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ICountFunction methods
public:

	// ICountFunction properties
public:

};

