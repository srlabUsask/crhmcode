// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CConvolveFilter wrapper class

class CConvolveFilter : public COleDispatchDriver
{
public:
	CConvolveFilter() {} // Calls COleDispatchDriver default constructor
	CConvolveFilter(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CConvolveFilter(const CConvolveFilter& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IConvolveFilter methods
public:

	// IConvolveFilter properties
public:

};

