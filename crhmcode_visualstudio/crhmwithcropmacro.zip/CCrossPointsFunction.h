// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CCrossPointsFunction wrapper class

class CCrossPointsFunction : public COleDispatchDriver
{
public:
	CCrossPointsFunction() {} // Calls COleDispatchDriver default constructor
	CCrossPointsFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CCrossPointsFunction(const CCrossPointsFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ICrossPointsFunction methods
public:

	// ICrossPointsFunction properties
public:

};

