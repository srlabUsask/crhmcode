// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CSmoothedMovAvgFunction wrapper class

class CSmoothedMovAvgFunction : public COleDispatchDriver
{
public:
	CSmoothedMovAvgFunction() {} // Calls COleDispatchDriver default constructor
	CSmoothedMovAvgFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CSmoothedMovAvgFunction(const CSmoothedMovAvgFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ISmoothedMovAvgFunction methods
public:

	// ISmoothedMovAvgFunction properties
public:

};
