// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CKurtosisFunction wrapper class

class CKurtosisFunction : public COleDispatchDriver
{
public:
	CKurtosisFunction() {} // Calls COleDispatchDriver default constructor
	CKurtosisFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CKurtosisFunction(const CKurtosisFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IKurtosisFunction methods
public:

	// IKurtosisFunction properties
public:

};
