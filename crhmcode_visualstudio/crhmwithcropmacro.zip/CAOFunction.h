// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CAOFunction wrapper class

class CAOFunction : public COleDispatchDriver
{
public:
	CAOFunction() {} // Calls COleDispatchDriver default constructor
	CAOFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CAOFunction(const CAOFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IAOFunction methods
public:

	// IAOFunction properties
public:

};

