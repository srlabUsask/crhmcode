// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CExpTrendFunction wrapper class

class CExpTrendFunction : public COleDispatchDriver
{
public:
	CExpTrendFunction() {} // Calls COleDispatchDriver default constructor
	CExpTrendFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CExpTrendFunction(const CExpTrendFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IExpTrendFunction methods
public:

	// IExpTrendFunction properties
public:

};

