#ifndef TDATETIME_H
#define TDATETIME_H



#include <atltime.h>
#include<sstream>
#include<iomanip>
using namespace std;


class TDateTime;


class TDateTime 
{
protected:


public:
	CTime 
	void operator=(TDateTime time)
	{
		this
	}
};



#endif // !TSTRINGLIST_H