// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CSepiaFilter wrapper class

class CSepiaFilter : public COleDispatchDriver
{
public:
	CSepiaFilter() {} // Calls COleDispatchDriver default constructor
	CSepiaFilter(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CSepiaFilter(const CSepiaFilter& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ISepiaFilter methods
public:

	// ISepiaFilter properties
public:

};
