// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CLowFunction wrapper class

class CLowFunction : public COleDispatchDriver
{
public:
	CLowFunction() {} // Calls COleDispatchDriver default constructor
	CLowFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CLowFunction(const CLowFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ILowFunction methods
public:

	// ILowFunction properties
public:

};
