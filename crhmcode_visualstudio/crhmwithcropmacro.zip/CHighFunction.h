// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CHighFunction wrapper class

class CHighFunction : public COleDispatchDriver
{
public:
	CHighFunction() {} // Calls COleDispatchDriver default constructor
	CHighFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CHighFunction(const CHighFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IHighFunction methods
public:

	// IHighFunction properties
public:

};

