// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CPercentChangeFunction wrapper class

class CPercentChangeFunction : public COleDispatchDriver
{
public:
	CPercentChangeFunction() {} // Calls COleDispatchDriver default constructor
	CPercentChangeFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CPercentChangeFunction(const CPercentChangeFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IPercentChangeFunction methods
public:

	// IPercentChangeFunction properties
public:

};
