// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CFlipFilter wrapper class

class CFlipFilter : public COleDispatchDriver
{
public:
	CFlipFilter() {} // Calls COleDispatchDriver default constructor
	CFlipFilter(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CFlipFilter(const CFlipFilter& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IFlipFilter methods
public:

	// IFlipFilter properties
public:

};

