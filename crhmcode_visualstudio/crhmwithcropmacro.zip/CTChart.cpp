// CTChart.cpp  : Definition of ActiveX Control wrapper class(es) created by Microsoft Visual C++


#include "stdafx.h"
#include "CTChart.h"

/////////////////////////////////////////////////////////////////////////////
// CTChart

IMPLEMENT_DYNCREATE(CTChart, CWnd)

// CTChart properties

// CTChart operations
