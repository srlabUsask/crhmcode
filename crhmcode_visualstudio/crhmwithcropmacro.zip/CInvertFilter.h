// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

//#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CInvertFilter wrapper class

class CInvertFilter : public COleDispatchDriver
{
public:
	CInvertFilter() {} // Calls COleDispatchDriver default constructor
	CInvertFilter(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CInvertFilter(const CInvertFilter& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// IInvertFilter methods
public:

	// IInvertFilter properties
public:

};

