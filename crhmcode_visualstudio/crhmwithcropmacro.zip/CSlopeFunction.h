// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CSlopeFunction wrapper class

class CSlopeFunction : public COleDispatchDriver
{
public:
	CSlopeFunction() {} // Calls COleDispatchDriver default constructor
	CSlopeFunction(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CSlopeFunction(const CSlopeFunction& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ISlopeFunction methods
public:

	// ISlopeFunction properties
public:

};
