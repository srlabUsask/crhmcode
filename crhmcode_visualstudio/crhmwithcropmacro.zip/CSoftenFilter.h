// Machine generated IDispatch wrapper class(es) created with Add Class from Typelib Wizard

#import "C:\\Program Files (x86)\\Steema Software\\TeeChart Pro v2018 ActiveX Evaluation\\TeeChart2018.ocx" no_namespace
// CSoftenFilter wrapper class

class CSoftenFilter : public COleDispatchDriver
{
public:
	CSoftenFilter() {} // Calls COleDispatchDriver default constructor
	CSoftenFilter(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CSoftenFilter(const CSoftenFilter& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// Attributes
public:

	// Operations
public:


	// ISoftenFilter methods
public:

	// ISoftenFilter properties
public:

};
